#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import ros_numpy
import numpy as np
from sensor_msgs.msg import Image
from segmentation_msgs.msg import ObjectsSegment, ObjectSegment
from ultralytics import YOLO
import cv2
import time

class UltralyticsSegmentationNode(Node):
    def __init__(self):
        super().__init__('ultralytics_segmentation')
        
        # Load the YOLO segmentation model
        self.segmentation_model = YOLO("yolov8n-seg.pt")
        self.get_logger().info("YOLOv8 model loaded successfully")

        # Publishers
        self.objects_segment_pub = self.create_publisher(
            ObjectsSegment, 
            "/ultralytics/segmentation/objects_segment", 
            10
        )
        self.seg_image_pub = self.create_publisher(
            Image, 
            "/ultralytics/segmentation/image", 
            10
        )

        # Subscriber
        self.rgb_sub = self.create_subscription(
            Image,
            "/camera/image_raw",
            self.callback,
            10
        )

    def callback(self, rgb_data):
        # Convert the RGB image to a NumPy array
        try:
            image = ros_numpy.numpify(rgb_data)
        except Exception as e:
            self.get_logger().error(f"Failed to convert image: {e}")
            return

        height, width, _ = image.shape
        self.get_logger().info(f"Received image with shape: {image.shape}")

        # Apply segmentation model to the RGB image
        seg_result = self.segmentation_model(image)

        # Prepare the ObjectsSegment message
        objects_msg = ObjectsSegment()
        objects_msg.header = rgb_data.header  # Copy the header from the RGB image
        objects_msg.header.stamp = self.get_clock().now().to_msg()

        for index, cls in enumerate(seg_result[0].boxes.cls):
            class_index = int(cls.cpu().numpy())
            name = seg_result[0].names[class_index]

            # Ensure result.masks is not None
            if seg_result[0].masks is not None:
                mask = seg_result[0].masks.data.cpu().numpy()[index, :, :]
                mask_resized = cv2.resize(mask, (width, height))
                binary_mask = (mask_resized > 0.5).astype(np.uint8)

                # Get pixel indices for the mask
                y_indices, x_indices = np.where(binary_mask > 0)

                if len(x_indices) == 0 or len(y_indices) == 0:
                    self.get_logger().warn(f"No valid indices found for object: {name}")
                    continue

                # Create ObjectSegment message
                obj_msg = ObjectSegment()
                obj_msg.header = objects_msg.header
                obj_msg.class_name = name
                obj_msg.probability = float(seg_result[0].boxes.conf[index].item())  # Accessing the probability score
                obj_msg.x_indices = x_indices.tolist()
                obj_msg.y_indices = y_indices.tolist()

                # Append the object segment to the array
                objects_msg.objects.append(obj_msg)
            else:
                self.get_logger().warn("Segmentation result has no masks")

        # Publish the ObjectsSegment message
        if objects_msg.objects:
            self.get_logger().info(f"Publishing {len(objects_msg.objects)} segmented objects")
            self.objects_segment_pub.publish(objects_msg)

        # Segmentation Visualization
        if self.seg_image_pub.get_subscription_count() > 0:
            try:
                # Generate and publish the annotated segmentation image
                seg_annotated = seg_result[0].plot(show=False)
                self.seg_image_pub.publish(ros_numpy.msgify(Image, seg_annotated, encoding="rgb8"))
                self.get_logger().info("Segmentation image published")
            except Exception as e:
                self.get_logger().error(f"Error while publishing segmentation image: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = UltralyticsSegmentationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

